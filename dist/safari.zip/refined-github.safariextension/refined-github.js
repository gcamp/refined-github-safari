/* globals gitHubInjection */
'use strict';

var path = location.pathname;
var ownerName = path.split('/')[1];
var repoName = path.split('/')[2];
var isDashboard = function isDashboard() {
	return location.pathname === '/' || /(^\/(dashboard))/.test(location.pathname) || /(^\/(orgs)\/)(\w|-)+\/(dashboard)/.test(location.pathname);
};
var isRepo = function isRepo() {
	return (/^\/[^/]+\/[^/]+/.test(location.pathname)
	);
};
var isRepoRoot = function isRepoRoot() {
	return location.pathname.replace(/\/$/, '') === '/' + ownerName + '/' + repoName || /(\/tree\/)(\w|\d|\.)+(\/$|$)/.test(location.href);
};
var isPR = function isPR() {
	return (/^\/[^/]+\/[^/]+\/pull\/\d+/.test(location.pathname) || /^\/[^/]+\/[^/]+\/pull\/\d+\/commits\/[0-9a-f]{5,40}/.test(location.pathname)
	);
};
var isCommit = function isCommit() {
	if (/^\/[^/]+\/[^/]+\/commit\/[0-9a-f]{5,40}/.test(location.pathname) || /^\/[^/]+\/[^/]+\/pull\/\d+\/commits\/[0-9a-f]{5,40}/.test(location.pathname)) {
		return true;
	}

	return (/^\/[^/]+\/[^/]+\/pull\/\d+\/files/.test(location.pathname) && $('.full-commit').length > 0
	);
};
var isIssue = function isIssue() {
	return (/^\/[^/]+\/[^/]+\/issues\/\d+$/.test(location.pathname)
	);
};
var isReleases = function isReleases() {
	return (/^\/[^/]+\/[^/]+\/(releases|tags)/.test(location.pathname)
	);
};
var isBlame = function isBlame() {
	return (/^\/[^/]+\/[^/]+\/blame\//.test(location.pathname)
	);
};
var getUsername = function getUsername() {
	return $('meta[name="user-login"]').attr('content');
};
var uselessContent = {
	upvote: { text: ['+1\n'], emoji: [':+1:', ':100:', ':ok_hand:'] },
	downvote: { text: ['-1\n'], emoji: [':-1:'] }
};

function linkifyBranchRefs() {
	$('.commit-ref').each(function (i, el) {
		var parts = $(el).find('.css-truncate-target');
		var branch = parts.eq(parts.length - 1).text();
		var username = ownerName;

		// if there are two parts the first part is the username
		if (parts.length > 1) {
			username = parts.eq(0).text();
		}

		$(el).wrap('<a href="https://github.com/' + username + '/' + repoName + '/tree/' + branch + '">');
	});
}

function commentIsUseless(type, el) {
	if (uselessContent[type].text.includes(el.innerText)) {
		return true;
	}
	// check if there is exactly one child element, that has one or two child nodes;
	// sometimes a second child node can contain a useless space
	// using `childNodes` because this also includes text nodes
	if (el.children.length === 1) {
		var children = el.children[0].childNodes;
		if (children.length === 1 || children.length === 2 && !children[1].textContent.trim()) {
			var onlyChild = children[0];
			if (onlyChild.tagName === 'IMG' && uselessContent[type].emoji.includes(onlyChild.title)) {
				return true;
			}
		}
	}

	return false;
}

function renderVoteCount(type, voters) {
	var iconUrl = undefined;
	if (type === 'upvote') {
		iconUrl = 'https://assets-cdn.github.com/images/icons/emoji/unicode/1f44d.png';
	}
	if (type === 'downvote') {
		iconUrl = 'https://assets-cdn.github.com/images/icons/emoji/unicode/1f44e.png';
	}
	var $sidebar = $('#partial-discussion-sidebar');
	var avatars = '';

	var _iteratorNormalCompletion = true;
	var _didIteratorError = false;
	var _iteratorError = undefined;

	try {
		for (var _iterator = voters[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
			var val = _step.value;

			avatars += val;
		}
	} catch (err) {
		_didIteratorError = true;
		_iteratorError = err;
	} finally {
		try {
			if (!_iteratorNormalCompletion && _iterator.return) {
				_iterator.return();
			}
		} finally {
			if (_didIteratorError) {
				throw _iteratorError;
			}
		}
	}

	avatars = avatars.replace(/height="48"/g, 'height="20"').replace(/width="48"/g, 'width="20"').replace(/<a href/g, '<a class="participant-avatar" href').replace(/timeline-comment-avatar/g, 'avatar');

	$sidebar.append('<div class="discussion-sidebar-item">\n\t\t\t<div class="participation">\n\t\t\t\t<h3 class="discussion-sidebar-heading">\n\t\t\t\t\t' + voters.size + ' <img class="emoji" alt="' + type + '" height="20" width="20" align="absmiddle" src="' + iconUrl + '">\n\t\t\t\t</h3>\n\t\t\t\t<div class="participation-avatars">\n\t\t\t\t\t' + avatars + '\n\t\t\t\t</div>\n\t\t\t</div>\n\t\t</div>');
}

function moveVotes() {
	var upVoters = new Set();
	var downVoters = new Set();
	$('.js-comment-body').each(function (i, el) {
		// this is a comment not in the usual container - found on inline comments
		if ($(el).closest('.js-comment-container').find('.author').length === 0) {
			return;
		}

		var isUp = commentIsUseless('upvote', el);
		var isDown = commentIsUseless('downvote', el);

		if (isUp || isDown) {
			// grab avatar and wrapping a tag for commenter
			var commenter = $($(el).closest('.js-comment-container').find('a').get(0)).wrap('<div>').parent().html();

			// remove from both arrays
			upVoters.delete(commenter);
			downVoters.delete(commenter);

			// add to upvoters if it's an upvote
			if (isUp) {
				upVoters.add(commenter);
			}

			// add to upvoters if it's an upvote
			if (isDown) {
				downVoters.add(commenter);
			}

			el.closest('.js-comment-container').remove();
		}
	});
	if (upVoters.size > 0) {
		renderVoteCount('upvote', upVoters);
	}
	if (downVoters.size > 0) {
		renderVoteCount('downvote', downVoters);
	}
}

function addReleasesTab() {
	var $repoNav = $('.js-repo-nav');
	var $releasesTab = $repoNav.children('[data-selected-links~="repo_releases"]');
	var hasReleases = $releasesTab.length > 0;

	if (!hasReleases) {
		$releasesTab = $('<a href="/' + ownerName + '/' + repoName + '/releases" class="reponav-item" data-hotkey="g r" data-selected-links="repo_releases /' + ownerName + '/' + repoName + '/releases">\n\t\t\t<svg class="octicon octicon-tag" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path d="M6.73 2.73c-0.47-0.47-1.11-0.73-1.77-0.73H2.5C1.13 2 0 3.13 0 4.5v2.47c0 0.66 0.27 1.3 0.73 1.77l6.06 6.06c0.39 0.39 1.02 0.39 1.41 0l4.59-4.59c0.39-0.39 0.39-1.02 0-1.41L6.73 2.73zM1.38 8.09c-0.31-0.3-0.47-0.7-0.47-1.13V4.5c0-0.88 0.72-1.59 1.59-1.59h2.47c0.42 0 0.83 0.16 1.13 0.47l6.14 6.13-4.73 4.73L1.38 8.09z m0.63-4.09h2v2H2V4z"></path></svg>\n\t\t\tReleases\n\t\t</a>');
	}

	if (isReleases()) {
		$repoNav.find('.selected').removeClass('js-selected-navigation-item selected');

		$releasesTab.addClass('js-selected-navigation-item selected');
	}

	if (!hasReleases) {
		$repoNav.append($releasesTab);
	}
}

function infinitelyMore() {
	var btn = $('.ajax-pagination-btn').get(0);

	// if there's no more button remove unnecessary event listeners
	if (!btn) {
		window.removeEventListener('scroll', infinitelyMore);
		window.removeEventListener('resize', infinitelyMore);
		return;
	}

	// grab dimensions to see if we should load
	var wHeight = window.innerHeight;
	var wScroll = window.pageYOffset || document.scrollTop;
	var btnOffset = $('.ajax-pagination-btn').offset().top;

	// smash the button if it's coming close to being in view
	if (wScroll > btnOffset - wHeight) {
		btn.click();
	}
}

function addBlameParentLinks() {
	$('.blame-sha').each(function (index, commitLink) {
		var $commitLink = $(commitLink);
		var $blameParentLink = $commitLink.clone();
		var commitSha = /\w{40}$/.exec(commitLink.href)[0];

		$blameParentLink.text('Blame ^').prop('href', location.pathname.replace(/(\/blame\/)[^\/]+/, '$1' + commitSha + encodeURI('^')));

		$commitLink.nextAll('.blame-commit-meta').append($blameParentLink);
	});
}

function addReadmeEditButton() {
	var readmeContainer = $('#readme');
	var readmeName = $('#readme > h3').text().trim();
	var currentBranch = $('.file-navigation .select-menu.left button.select-menu-button').attr('title');
	var editHref = '/' + ownerName + '/' + repoName + '/edit/' + currentBranch + '/' + readmeName;
	var editButtonHtml = '<div id="refined-github-readme-edit-link">\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a href="' + editHref + '">\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<svg class="octicon octicon-pencil" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path d="M0 12v3h3l8-8-3-3L0 12z m3 2H1V12h1v1h1v1z m10.3-9.3l-1.3 1.3-3-3 1.3-1.3c0.39-0.39 1.02-0.39 1.41 0l1.59 1.59c0.39 0.39 0.39 1.02 0 1.41z"></path></svg>\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t</a>\n\t\t\t\t\t\t\t\t\t\t\t\t\t</div>';

	readmeContainer.append(editButtonHtml);
}

function addDeleteForkLink() {
	var postMergeContainer = $('#partial-pull-merging');

	if (postMergeContainer.length > 0) {
		var postMergeDescription = $(postMergeContainer).find('.merge-branch-description').get(0);
		var forkPath = $(postMergeContainer).attr('data-channel').split(':')[0];

		if (forkPath !== ownerName + '/' + repoName) {
			$(postMergeDescription).append('<p id="refined-github-delete-fork-link">\n\t\t\t\t\t<a href="https://github.com/' + forkPath + '/settings">\n\t\t\t\t\t\t<svg aria-hidden="true" class="octicon octicon-repo-forked" height="16" role="img" version="1.1" viewBox="0 0 10 16" width="10"><path d="M8 1c-1.11 0-2 0.89-2 2 0 0.73 0.41 1.38 1 1.72v1.28L5 8 3 6v-1.28c0.59-0.34 1-0.98 1-1.72 0-1.11-0.89-2-2-2S0 1.89 0 3c0 0.73 0.41 1.38 1 1.72v1.78l3 3v1.78c-0.59 0.34-1 0.98-1 1.72 0 1.11 0.89 2 2 2s2-0.89 2-2c0-0.73-0.41-1.38-1-1.72V9.5l3-3V4.72c0.59-0.34 1-0.98 1-1.72 0-1.11-0.89-2-2-2zM2 4.2c-0.66 0-1.2-0.55-1.2-1.2s0.55-1.2 1.2-1.2 1.2 0.55 1.2 1.2-0.55 1.2-1.2 1.2z m3 10c-0.66 0-1.2-0.55-1.2-1.2s0.55-1.2 1.2-1.2 1.2 0.55 1.2 1.2-0.55 1.2-1.2 1.2z m3-10c-0.66 0-1.2-0.55-1.2-1.2s0.55-1.2 1.2-1.2 1.2 0.55 1.2 1.2-0.55 1.2-1.2 1.2z"></path></svg>\n\t\t\t\t\t\tDelete fork\n\t\t\t\t\t</a>\n\t\t\t\t</p>');
		}
	}
}

function linkifyIssuesInTitles() {
	var $title = $('.js-issue-title');
	var titleText = $title.text();

	if (/(#\d+)/.test(titleText)) {
		$title.html(titleText.replace(/#(\d+)/g, '<a href="https://github.com/' + ownerName + '/' + repoName + '/issues/$1">#$1</a>'));
	}
}

function addPatchDiffLinks() {
	var commitUrl = location.href.replace(/\/$/, '');
	var commitMeta = $('.commit-meta span.right').get(0);

	$(commitMeta).append('\n\t\t<span class="sha-block">\n\t\t\t<a href="' + commitUrl + '.patch" class="sha">.patch</a>\n\t\t\t<a href="' + commitUrl + '.diff" class="sha">.diff</a>\n\t\t</span>\n\t');
}

// Prompt user to confirm erasing a comment with the Cancel button
$(document).on('click', function (event) {
	// Check event.target instead of using a delegate, because Sprint doesn't support them
	var $target = $(event.target);
	if (!$target.hasClass('js-hide-inline-comment-form')) {
		return;
	}

	// Do not prompt if textarea is empty
	var text = $target.closest('.js-inline-comment-form').find('.js-comment-field').val();
	if (text.length === 0) {
		return;
	}

	if (window.confirm('Are you sure you want to discard your unsaved changes?') === false) {
		// eslint-disable-line no-alert
		event.stopPropagation();
		event.stopImmediatePropagation();
	}
});

// Collapse file diffs when clicking the file header
$(document).on('click', function (event) {
	// Check event.target instead of using a delegate, because Sprint doesn't support them
	var $target = $(event.target);
	if (!($target.closest('.file-header').length > 0 && $target.closest('.file-actions').length === 0)) {
		return;
	}

	$target.closest('.js-details-container').toggleClass('refined-github-minimized');
});

document.addEventListener('DOMContentLoaded', function () {
	var username = getUsername();

	if (isDashboard()) {
		(function () {
			// hide other users starring/forking your repos
			var hideStarsOwnRepos = function hideStarsOwnRepos() {
				$('#dashboard .news .watch_started, #dashboard .news .fork').has('.title a[href^="/' + username + '"]').css('display', 'none');
			};

			hideStarsOwnRepos();

			new MutationObserver(function () {
				return hideStarsOwnRepos();
			}).observe($('#dashboard .news').get(0), { childList: true });

			// event binding for infinite scroll
			window.addEventListener('scroll', infinitelyMore);
			window.addEventListener('resize', infinitelyMore);
		})();
	}

	if (isRepo()) {
		gitHubInjection(window, function () {
			addReleasesTab();

			if (isPR()) {
				linkifyBranchRefs();
				addDeleteForkLink();
			}

			if (isPR() || isIssue()) {
				moveVotes();
				linkifyIssuesInTitles();
			}

			if (isBlame()) {
				addBlameParentLinks();
			}

			if (isRepoRoot()) {
				addReadmeEditButton();
			}

			if (isCommit()) {
				addPatchDiffLinks();
			}
		});
	}
});
// https://github.com/octo-linker/injection 0.2.0
'use strict';

var gitHubInjection = function gitHubInjection(global, cb) {
  if (!global) {
    throw new Error('Missing argument global');
  }

  if (!global.document || !global.document.getElementById) {
    throw new Error('The given argument global is not a valid window object');
  }

  if (!cb) {
    throw new Error('Missing argument callback');
  }

  if (typeof cb !== 'function') {
    throw new Error('Callback is not a function');
  }

  var domElement = global.document.getElementById('js-repo-pjax-container');
  if (!domElement || !global.MutationObserver) {
    return cb(null);
  }

  var viewSpy = new global.MutationObserver(function (mutations) {
    mutations.forEach(function (mutation) {
      if (mutation.type === 'childList' && mutation.addedNodes.length) {
        cb(null);
      }
    });
  });

  viewSpy.observe(domElement, {
    attributes: true,
    childList: true,
    characterData: true
  });

  cb(null);
};

// Export the gitHubInjection function for **Node.js**, with
// backwards-compatibility for the old `require()` API. If we're in
// the browser, add `gitHubInjection` as a global object.
if (typeof exports !== 'undefined') {
  if (typeof module !== 'undefined' && module.exports) {
    exports = module.exports = gitHubInjection;
  }
  exports.gitHubInjection = gitHubInjection;
} else {
  /*jshint -W040 */
  undefined.gitHubInjection = gitHubInjection;
  /*jshint +W040 */
}
"use strict";

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol ? "symbol" : typeof obj; };

// Sprint v0.9.2 - sprintjs.com/license
var Sprint;
(function () {
  var D = function D(a, b) {
    for (var c = Sprint(b), d = Object.keys(a), e = d.length, f = 0; f < e; f++) {
      for (var g = d[f], h = a[g], k = h.length, l = 0; l < k; l++) {
        c.on(g, h[l]);
      }
    }
  },
      w = function () {
    var a = "animation-iteration-count column-count flex-grow flex-shrink font-weight line-height opacity order orphans widows z-index".split(" ");return function (b, c) {
      if (v(b, a)) return c;var d = "string" == typeof c ? c : c.toString();c && !/\D/.test(d) && (d += "px");return d;
    };
  }(),
      K = { afterbegin: function afterbegin(a) {
      this.insertBefore(a, this.firstChild);
    }, afterend: function afterend(a) {
      var b = this.parentElement;b && b.insertBefore(a, this.nextSibling);
    }, beforebegin: function beforebegin(a) {
      var b = this.parentElement;b && b.insertBefore(a, this);
    }, beforeend: function beforeend(a) {
      this.appendChild(a);
    } },
      E = function E(a, b) {
    if (!(1 < a.nodeType)) {
      var c = a.sprintEventListeners;c && D(c, b);for (var d = r("*", a), e = d.length, f, g = 0; g < e; g++) {
        if (c = d[g].sprintEventListeners) f || (f = r("*", b)), D(c, f[g]);
      }
    }
  },
      z = function z(a, b, c, d, e) {
    var f = [],
        g = this;this.each(function () {
      for (var h = a ? this.parentElement : this; h && (!e || e != h);) {
        if (!d || g.is(d, h)) if (f.push(h), c) break;
        if (b) break;h = h.parentElement;
      }
    });return Sprint(x(f));
  },
      F = function F(a, b) {
    return Object.keys(a.sprintEventListeners).filter(function (a) {
      return q(b).every(function (b) {
        return v(b, q(a));
      });
    });
  },
      G = function G(a, b, c) {
    if (null == c) {
      var d = a.get(0);if (!d || 1 < d.nodeType) return;a = b[0].toUpperCase() + b.substring(1);return d == document ? (d = m["offset" + a], a = window["inner" + a], d > a ? d : a) : d == window ? window["inner" + a] : d.getBoundingClientRect()[b];
    }var e = "function" == typeof c,
        f = e ? "" : w(b, c);return a.each(function (a) {
      this == document || this == window || 1 < this.nodeType || (e && (f = w(b, c.call(this, a, Sprint(this)[b]()))), this.style[b] = f);
    });
  },
      p = function p(a, b) {
    var c = b.length,
        d = b;if (1 < c && -1 < a.indexOf("after")) for (var d = [], e = c; e--;) {
      d.push(b[e]);
    }for (e = 0; e < c; e++) {
      var f = d[e];if ("string" == typeof f || "number" == typeof f) this.each(function () {
        this.insertAdjacentHTML(a, f);
      });else if ("function" == typeof f) this.each(function (b) {
        b = f.call(this, b, this.innerHTML);p.call(Sprint(this), a, [b]);
      });else {
        var g = f instanceof n,
            h = [],
            k = g ? f.get() : Array.isArray(f) ? A(f, !0, !0) : f.nodeType ? [f] : t(f),
            l = k.length;this.each(function (b) {
          for (var c = document.createDocumentFragment(), d = 0; d < l; d++) {
            var e = k[d],
                f;b ? (f = e.cloneNode(!0), E(e, f)) : f = e;c.appendChild(f);h.push(f);
          }K[a].call(this, c);
        });g && (f.dom = h, f.length = h.length);if (!(e < c - 1)) return h;
      }
    }
  },
      v = function v(a, b) {
    for (var c = b.length; c--;) {
      if (b[c] === a) return !0;
    }return !1;
  },
      B = function B(a, b, c) {
    if (null == b) return "add" == a ? this : this.removeAttr("class");var d, e, f;"string" == typeof b && (d = !0, e = b.trim().split(" "), f = e.length);return this.each(function (g, h) {
      if (!(1 < this.nodeType)) {
        if (!d) {
          var k = b.call(h, g, h.className);if (!k) return;e = k.trim().split(" ");f = e.length;
        }for (k = 0; k < f; k++) {
          var l = e[k];l && (null == c ? h.classList[a](l) : h.classList.toggle(l, c));
        }
      }
    });
  },
      L = function () {
    for (var a = ["mozMatchesSelector", "webkitMatchesSelector", "msMatchesSelector", "matches"], b = a.length; b--;) {
      var c = a[b];if (Element.prototype[c]) return c;
    }
  }(),
      x = function x(a) {
    for (var b = [], c = 0, d = a.length, e = 0; e < d; e++) {
      for (var f = a[e], g = !1, h = 0; h < c; h++) {
        if (f === b[h]) {
          g = !0;break;
        }
      }g || (b[c++] = f);
    }return b;
  },
      H = function () {
    var a = function a(_a, b, c) {
      return 2 > Object.keys(_a.sprintEventListeners).filter(function (a) {
        return q(b)[0] === q(a)[0];
      }).map(function (b) {
        return _a.sprintEventListeners[b];
      }).reduce(function (a, b) {
        return a.concat(b);
      }).filter(function (a) {
        return a === c;
      }).length ? !1 : !0;
    },
        b = function b(_b, c, f) {
      return function (g) {
        f && f !== g || (_b.removeEventListener(c, g), /\./.test(c) && !a(_b, c, g) && _b.removeEventListener(q(c)[0], g));
      };
    },
        c = function c(a, b) {
      return a.filter(function (a) {
        return b && b !== a;
      });
    };return function (a, e) {
      return function (f) {
        a.sprintEventListeners[f].forEach(b(a, f, e));a.sprintEventListeners[f] = c(a.sprintEventListeners[f], e);
      };
    };
  }(),
      M = function M(a, b) {
    return function (c) {
      F(a, c).forEach(H(a, b));
    };
  },
      m = document.documentElement,
      A = function A(a, b, c) {
    for (var d = a.length, e = d; e--;) {
      if (!a[e] && 0 !== a[e] || b && a[e] instanceof n || c && ("string" == typeof a[e] || "number" == typeof a[e])) {
        for (var e = [], f = 0; f < d; f++) {
          var g = a[f];if (g || 0 === g) if (b && g instanceof n) for (var h = 0; h < g.length; h++) {
            e.push(g.get(h));
          } else !c || "string" != typeof g && "number" != typeof g ? e.push(g) : e.push(document.createTextNode(g));
        }return e;
      }
    }return a;
  },
      I = function () {
    var a;return function (b, c, d) {
      if (!a) {
        var e = m.scrollTop;m.scrollTop = e + 1;var f = m.scrollTop;m.scrollTop = e;a = f > e ? m : document.body;
      }if (null == d) {
        b = b.get(0);if (!b) return;if (b == window || b == document) b = a;return b[c];
      }return b.each(function () {
        var b = this;if (b == window || b == document) b = a;b[c] = d;
      });
    };
  }(),
      y = function y(a, b, c, d) {
    var e = [],
        f = b + "ElementSibling";a.each(function () {
      for (var b = this; (b = b[f]) && (!d || !a.is(d, b));) {
        c && !a.is(c, b) || e.push(b);
      }
    });return Sprint(x(e));
  },
      J = function J(a, b, c) {
    var d = b + "ElementSibling";return a.map(function () {
      var b = this[d];if (b && (!c || a.is(c, b))) return b;
    }, !1);
  },
      r = function r(a, b) {
    b = b || document;if (/^[\#.]?[\w-]+$/.test(a)) {
      var c = a[0];return "." == c ? t(b.getElementsByClassName(a.slice(1))) : "#" == c ? (c = b.getElementById(a.slice(1))) ? [c] : [] : "body" == a ? [document.body] : t(b.getElementsByTagName(a));
    }return t(b.querySelectorAll(a));
  },
      q = function q(a) {
    return A(a.split("."));
  },
      t = function t(a) {
    for (var b = [], c = a.length; c--;) {
      b[c] = a[c];
    }return b;
  },
      C = function () {
    var a = function a(_a2, c) {
      var d = Sprint(_a2).clone(!0).get(0),
          e = d;if (d && !(1 < this.nodeType)) {
        for (; e.firstChild;) {
          e = e.firstChild;
        }if ("inner" == c) {
          for (; this.firstChild;) {
            e.appendChild(this.firstChild);
          }this.appendChild(d);
        } else {
          var f = "all" == c ? this.get(0) : this,
              g = f.parentNode,
              h = f.nextSibling;"all" == c ? this.each(function () {
            e.appendChild(this);
          }) : e.appendChild(f);g.insertBefore(d, h);
        }
      }
    };return function (b, c) {
      "function" == typeof b ? this.each(function (a) {
        Sprint(this)["inner" == c ? "wrapInner" : "wrap"](b.call(this, a));
      }) : "all" == c ? a.call(this, b, c) : this.each(function () {
        a.call(this, b, c);
      });return this;
    };
  }(),
      u = { legend: { intro: "<fieldset>", outro: "</fieldset>" },
    area: { intro: "<map>", outro: "</map>" }, param: { intro: "<object>", outro: "</object>" }, thead: { intro: "<table>", outro: "</table>" }, tr: { intro: "<table><tbody>", outro: "</tbody></table>" }, col: { intro: "<table><tbody></tbody><colgroup>", outro: "</colgroup></table>" }, td: { intro: "<table><tbody><tr>", outro: "</tr></tbody></table>" } };["tbody", "tfoot", "colgroup", "caption"].forEach(function (a) {
    u[a] = u.thead;
  });u.th = u.td;var n = function n(a, b) {
    if ("string" == typeof a) {
      if ("<" == a[0]) {
        var c = document.createElement("div"),
            d = /[\w:-]+/.exec(a)[0],
            d = u[d],
            e = a.trim();d && (e = d.intro + e + d.outro);c.insertAdjacentHTML("afterbegin", e);e = c.lastChild;if (d) for (d = d.outro.match(/</g).length; d--;) {
          e = e.lastChild;
        }c.textContent = "";this.dom = [e];
      } else this.dom = b && b instanceof n ? b.find(a).get() : r(a, b);
    } else if (Array.isArray(a)) this.dom = A(a);else if (a instanceof NodeList || a instanceof HTMLCollection) this.dom = t(a);else {
      if (a instanceof n) return a;if ("function" == typeof a) return this.ready(a);this.dom = a ? [a] : [];
    }this.length = this.dom.length;
  };n.prototype = { add: function add(a) {
      var b = this.get();a = Sprint(a);for (var c = a.get(), d = 0; d < a.length; d++) {
        b.push(c[d]);
      }return Sprint(x(b));
    }, addClass: function addClass(a) {
      return B.call(this, "add", a);
    }, after: function after() {
      p.call(this, "afterend", arguments);return this;
    }, append: function append() {
      p.call(this, "beforeend", arguments);return this;
    }, appendTo: function appendTo(a) {
      return Sprint(p.call(Sprint(a), "beforeend", [this]));
    }, attr: function attr(a, b) {
      var c = "function" == typeof b;if ("string" == typeof b || "number" == typeof b || c) return this.each(function (d) {
        1 < this.nodeType || this.setAttribute(a, c ? b.call(this, d, this.getAttribute(a)) : b);
      });if ("object" == (typeof a === "undefined" ? "undefined" : _typeof(a))) {
        var d = Object.keys(a),
            e = d.length;return this.each(function () {
          if (!(1 < this.nodeType)) for (var b = 0; b < e; b++) {
            var c = d[b];this.setAttribute(c, a[c]);
          }
        });
      }var f = this.get(0);if (f && !(1 < f.nodeType)) return f = f.getAttribute(a), null == f ? void 0 : f ? f : a;
    }, before: function before() {
      p.call(this, "beforebegin", arguments);return this;
    }, children: function children(a) {
      var b = [],
          c = this;this.each(function () {
        if (!(1 < this.nodeType)) for (var d = this.children, e = d.length, f = 0; f < e; f++) {
          var g = d[f];
          a && !c.is(a, g) || b.push(g);
        }
      });return Sprint(b);
    }, clone: function clone(a) {
      return this.map(function () {
        if (this) {
          var b = this.cloneNode(!0);a && E(this, b);return b;
        }
      }, !1);
    }, closest: function closest(a, b) {
      return z.call(this, !1, !1, !0, a, b);
    }, css: function css(a, b) {
      var c = typeof b === "undefined" ? "undefined" : _typeof(b),
          d = "string" == c;if (d || "number" == c) {
        var e = d && /=/.test(b);if (e) var f = parseInt(b[0] + b.slice(2));return this.each(function () {
          if (!(1 < this.nodeType)) {
            if (e) var c = parseInt(getComputedStyle(this).getPropertyValue(a)) + f;this.style[a] = w(a, e ? c : b);
          }
        });
      }if ("function" == c) return this.each(function (c) {
        if (!(1 < this.nodeType)) {
          var d = getComputedStyle(this).getPropertyValue(a);this.style[a] = b.call(this, c, d);
        }
      });if ("string" == typeof a) return d = this.get(0), !d || 1 < d.nodeType ? void 0 : getComputedStyle(d).getPropertyValue(a);if (Array.isArray(a)) {
        d = this.get(0);if (!d || 1 < d.nodeType) return;for (var c = {}, d = getComputedStyle(d), g = a.length, h = 0; h < g; h++) {
          var k = a[h];c[k] = d.getPropertyValue(k);
        }return c;
      }var l = Object.keys(a),
          m = l.length;return this.each(function () {
        if (!(1 < this.nodeType)) for (var b = 0; b < m; b++) {
          var c = l[b];this.style[c] = w(c, a[c]);
        }
      });
    }, detach: function detach() {
      return this.map(function () {
        var a = this.parentElement;if (a) return a.removeChild(this), this;
      }, !1);
    }, each: function each(a) {
      for (var b = this.dom, c = this.length, d = 0; d < c; d++) {
        var e = b[d];a.call(e, d, e);
      }return this;
    }, empty: function empty() {
      return this.each(function () {
        this.innerHTML = "";
      });
    }, eq: function eq(a) {
      return Sprint(this.get(a));
    }, filter: function filter(a) {
      var b = "function" == typeof a,
          c = this;return this.map(function (d) {
        if (!(1 < this.nodeType || !b && !c.is(a, this) || b && !a.call(this, d, this))) return this;
      }, !1);
    },
    find: function find(a) {
      if ("string" == typeof a) {
        var b = [];this.each(function () {
          if (!(1 < this.nodeType)) for (var c = r(a, this), d = c.length, e = 0; e < d; e++) {
            b.push(c[e]);
          }
        });return Sprint(x(b));
      }for (var c = a.nodeType ? [a] : a.get(), d = c.length, e = [], f = 0, g = 0; g < this.length; g++) {
        var h = this.get(g);if (!(1 < h.nodeType)) for (var k = 0; k < d; k++) {
          var l = c[k];if (h.contains(l) && (e[f++] = l, !(f < d))) return Sprint(e);
        }
      }return Sprint(e);
    }, first: function first() {
      return this.eq(0);
    }, get: function get(a) {
      if (null == a) return this.dom;0 > a && (a += this.length);return this.dom[a];
    },
    has: function has(a) {
      if ("string" == typeof a) return this.map(function () {
        if (!(1 < this.nodeType) && r(a, this)[0]) return this;
      }, !1);for (var b = [], c = this.length; c--;) {
        var d = this.get(c);if (d.contains(a)) {
          b.push(d);break;
        }
      }return Sprint(b);
    }, hasClass: function hasClass(a) {
      for (var b = this.length; b--;) {
        var c = this.get(b);if (1 < c.nodeType) return;if (c.classList.contains(a)) return !0;
      }return !1;
    }, height: function height(a) {
      return G(this, "height", a);
    }, html: function html(a) {
      if (null == a) {
        var b = this.get(0);return b ? b.innerHTML : void 0;
      }return "function" == typeof a ? this.each(function (b) {
        b = a.call(this, b, this.innerHTML);Sprint(this).html(b);
      }) : this.each(function () {
        this.innerHTML = a;
      });
    }, index: function index(a) {
      if (this.length) {
        var b;a ? "string" == typeof a ? (b = this.get(0), a = Sprint(a)) : (b = a instanceof n ? a.get(0) : a, a = this) : (b = this.get(0), a = this.first().parent().children());a = a.get();for (var c = a.length; c--;) {
          if (a[c] == b) return c;
        }return -1;
      }
    }, insertAfter: function insertAfter(a) {
      Sprint(a).after(this);return this;
    }, insertBefore: function insertBefore(a) {
      Sprint(a).before(this);return this;
    }, is: function is(a, b) {
      var c = b ? [b] : this.get(),
          d = c.length;if ("string" == typeof a) {
        for (var e = 0; e < d; e++) {
          var f = c[e];if (!(1 < f.nodeType) && f[L](a)) return !0;
        }return !1;
      }if ("object" == (typeof a === "undefined" ? "undefined" : _typeof(a))) {
        for (var f = a instanceof n ? a.get() : a.length ? a : [a], g = f.length, e = 0; e < d; e++) {
          for (var h = 0; h < g; h++) {
            if (c[e] === f[h]) return !0;
          }
        }return !1;
      }if ("function" == typeof a) {
        for (e = 0; e < d; e++) {
          if (a.call(this, e, this)) return !0;
        }return !1;
      }
    }, last: function last() {
      return this.eq(-1);
    }, map: function map(a, b) {
      null == b && (b = !0);for (var c = this.get(), d = this.length, e = [], f = 0; f < d; f++) {
        var g = c[f],
            g = a.call(g, f, g);if (b && Array.isArray(g)) for (var h = g.length, k = 0; k < h; k++) {
          e.push(g[k]);
        } else e.push(g);
      }return Sprint(e);
    }, next: function next(a) {
      return J(this, "next", a);
    }, nextAll: function nextAll(a) {
      return y(this, "next", a);
    }, nextUntil: function nextUntil(a, b) {
      return y(this, "next", b, a);
    }, not: function not(a) {
      var b = "function" == typeof a,
          c = this;return this.map(function (d) {
        if (b) {
          if (a.call(this, d, this)) return;
        } else if (c.is(a, this)) return;return this;
      }, !1);
    }, off: function off(a, b) {
      if ("object" == (typeof a === "undefined" ? "undefined" : _typeof(a))) return Object.keys(a).forEach(function (b) {
        this.off(b, a[b]);
      }, this), this;a && (a = a.trim().split(" "));return this.each(function () {
        this.sprintEventListeners && (a ? a.forEach(M(this, b)) : Object.keys(this.sprintEventListeners).forEach(H(this)));
      });
    }, offset: function offset(a) {
      if (!a) {
        var b = this.get(0);if (!b || 1 < b.nodeType) return;b = b.getBoundingClientRect();return { top: b.top, left: b.left };
      }if ("object" == (typeof a === "undefined" ? "undefined" : _typeof(a))) return this.each(function () {
        if (!(1 < this.nodeType)) {
          var b = Sprint(this);"static" == b.css("position") ? b.css("position", "relative") : b.css({ top: 0, left: 0 });var d = b.offset();b.css({ top: a.top - d.top + "px", left: a.left - d.left + "px" });
        }
      });if ("function" == typeof a) return this.each(function (b) {
        var d = Sprint(this);b = a.call(this, b, d.offset());d.offset(b);
      });
    }, offsetParent: function offsetParent() {
      var a = [];this.each(function () {
        if (!(1 < this.nodeType)) {
          for (var b = this; b != m;) {
            var b = b.parentNode,
                c = getComputedStyle(b).getPropertyValue("position");if (!c) break;if ("static" != c) {
              a.push(b);return;
            }
          }a.push(m);
        }
      });return Sprint(a);
    }, on: function on(a, b) {
      if (b) {
        var c = a.trim().split(" ");return this.each(function () {
          this.sprintEventListeners || (this.sprintEventListeners = {});c.forEach(function (a) {
            this.sprintEventListeners[a] || (this.sprintEventListeners[a] = []);this.sprintEventListeners[a].push(b);this.addEventListener(a, b);/\./.test(a) && this.addEventListener(q(a)[0], b);
          }, this);
        });
      }Object.keys(a).forEach(function (b) {
        this.on(b, a[b]);
      }, this);return this;
    }, parent: function parent(a) {
      return z.call(this, !0, !0, !1, a);
    }, parents: function parents(a) {
      return z.call(this, !0, !1, !1, a);
    }, position: function position() {
      var a = this.offset(),
          b = this.parent().offset();if (a) return { top: a.top - b.top,
        left: a.left - b.left };
    }, prop: function prop(a, b) {
      if ("object" == (typeof a === "undefined" ? "undefined" : _typeof(a))) {
        var c = Object.keys(a),
            d = c.length;return this.each(function () {
          for (var b = 0; b < d; b++) {
            var e = c[b];this[e] = a[e];
          }
        });
      }if (null == b) {
        var e = this.get(0);return e ? e[a] : void 0;
      }var f = "function" == typeof b;return this.each(function (c) {
        this[a] = f ? b.call(this, c, this[a]) : b;
      });
    }, prepend: function prepend() {
      p.call(this, "afterbegin", arguments);return this;
    }, prependTo: function prependTo(a) {
      return Sprint(p.call(Sprint(a), "afterbegin", [this]));
    }, prev: function prev(a) {
      return J(this, "previous", a);
    }, prevAll: function prevAll(a) {
      return y(this, "previous", a);
    }, prevUntil: function prevUntil(a, b) {
      return y(this, "previous", b, a);
    }, ready: function ready(a) {
      this.dom = [document];this.length = 1;return this.on("DOMContentLoaded", a);
    }, remove: function remove(a) {
      var b = this;return this.each(function () {
        var c = this.parentElement;c && (a && !b.is(a, this) || c.removeChild(this));
      });
    }, removeAttr: function removeAttr(a) {
      if (a) {
        var b = a.trim().split(" "),
            c = b.length;this.each(function () {
          if (!(1 < this.nodeType)) for (var a = 0; a < c; a++) {
            this.removeAttribute(b[a]);
          }
        });
      }return this;
    }, removeClass: function removeClass(a) {
      return B.call(this, "remove", a);
    }, removeProp: function removeProp(a) {
      return this.each(function () {
        this[a] = void 0;
      });
    }, replaceAll: function replaceAll(a) {
      Sprint(a).replaceWith(this);return this;
    }, replaceWith: function replaceWith(a) {
      return "function" == typeof a ? this.each(function (b) {
        Sprint(this).replaceWith(a.call(this, b, this));
      }) : this.before(a).remove();
    }, scrollLeft: function scrollLeft(a) {
      return I(this, "scrollLeft", a);
    }, scrollTop: function scrollTop(a) {
      return I(this, "scrollTop", a);
    }, siblings: function siblings(a) {
      var b = [],
          c = this;this.each(function (d, e) {
        Sprint(this).parent().children().each(function () {
          this == e || a && !c.is(a, this) || b.push(this);
        });
      });return Sprint(b);
    }, size: function size() {
      return this.length;
    }, slice: function slice(a, b) {
      var c = this.get(),
          d = [],
          e = 0 <= a ? a : a + this.length,
          f = this.length;for (0 > b ? f += b : 0 <= b && (f = b > this.length ? this.length : b); e < f; e++) {
        d.push(c[e]);
      }return Sprint(d);
    }, text: function text(a) {
      if (null == a) {
        var b = [];this.each(function () {
          b.push(this.textContent);
        });return b.join("");
      }var c = "function" == typeof a;return this.each(function (b) {
        this.textContent = c ? a.call(this, b, this.textContent) : a;
      });
    }, toggleClass: function toggleClass(a, b) {
      return B.call(this, "toggle", a, b);
    }, trigger: function trigger(a) {
      if (!window.CustomEvent || "function" !== typeof window.CustomEvent) {
        var b = function b(a, _b2) {
          var e;_b2 = _b2 || { bubbles: !1, cancelable: !1, detail: void 0 };e = document.createEvent("CustomEvent");e.initCustomEvent(a, _b2.bubbles, _b2.cancelable, _b2.detail);return e;
        };b.prototype = window.Event.prototype;window.CustomEvent = b;
      }return this.each(function () {
        F(this, a).forEach(function (a) {
          this.dispatchEvent(new b(a, { bubbles: !0, cancelable: !0 }));
        }, this);
      });
    }, unwrap: function unwrap() {
      this.parent().each(function () {
        this != document.body && this != m && Sprint(this).replaceWith(this.childNodes);
      });return this;
    }, val: function val(a) {
      if (null == a) {
        var b = this.get(0);if (!b) return;if (b.multiple) {
          var c = [];this.first().children(":checked").each(function () {
            c.push(this.value);
          });return c;
        }return b.value;
      }if (Array.isArray(a)) {
        var d = this;return this.each(function () {
          this.multiple ? d.children().each(function () {
            this.selected = v(this.value, a);
          }) : this.checked = v(this.value, a);
        });
      }return "function" == typeof a ? this.each(function (b) {
        Sprint(this).val(a.call(this, b, this.value));
      }) : this.each(function () {
        this.value = a;
      });
    }, width: function width(a) {
      return G(this, "width", a);
    }, wrap: function wrap(a) {
      return C.call(this, a);
    }, wrapAll: function wrapAll(a) {
      return C.call(this, a, "all");
    }, wrapInner: function wrapInner(a) {
      return C.call(this, a, "inner");
    } };Sprint = function Sprint(a, b) {
    return new n(a, b);
  };null == window.$ && (window.$ = Sprint);
})();